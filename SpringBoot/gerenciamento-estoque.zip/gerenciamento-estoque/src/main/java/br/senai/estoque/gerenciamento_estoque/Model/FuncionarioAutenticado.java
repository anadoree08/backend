package br.senai.estoque.gerenciamento_estoque.Model;

public class FuncionarioAutenticado {
    
}

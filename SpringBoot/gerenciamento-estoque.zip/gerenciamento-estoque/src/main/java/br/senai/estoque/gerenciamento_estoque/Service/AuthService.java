package br.senai.estoque.gerenciamento_estoque.Service;

public class AuthService {
    
}

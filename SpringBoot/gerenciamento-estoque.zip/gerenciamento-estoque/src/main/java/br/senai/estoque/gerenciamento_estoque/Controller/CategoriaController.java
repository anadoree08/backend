package br.senai.estoque.gerenciamento_estoque.Controller;



import java.util.List;

import org.springframework.web.bind.annotation.*; // Importa anotações usadas para criar endpoints da API

import br.senai.estoque.gerenciamento_estoque.Model.Categoria; // Importa a entidade Categoria do sistema

//import br.senai.estoque.gerenciamentoestoque.model.Categoria;
//import br.senai.estoque.gerenciamentoestoque.repository.CategoriaRepository;

@RestController
@RequestMapping("/categorias") // Define o caminho base da API para categorias
public class CategoriaController {

    private final br.senai.estoque.gerenciamento_estoque.Repository.CategoriaRepository repository;

    public CategoriaController(br.senai.estoque.gerenciamento_estoque.Repository.CategoriaRepository repository) {
        this.repository = repository;
    }

    // essa parte é responsável por listar
    @GetMapping
    public List<br.senai.estoque.gerenciamento_estoque.Model.Categoria> listar() {
        return repository.findAll();
    }

    // essa parte vai criar 
    @PostMapping
    public br.senai.estoque.gerenciamento_estoque.Model.Categoria criar(@RequestBody br.senai.estoque.gerenciamento_estoque.Model.Categoria categoria) {
        return repository.save(categoria);
    }

    // Aqui a gente busca por id 
    @GetMapping("/{id}")
    public br.senai.estoque.gerenciamento_estoque.Model.Categoria buscar(@PathVariable Long id) {
        return repository.findById(id).orElse(null);
    }

    // aqui é pra página recarregar e atualizar
    @PutMapping("/{id}")
    public br.senai.estoque.gerenciamento_estoque.Model.Categoria atualizar(@PathVariable Long id, @RequestBody br.senai.estoque.gerenciamento_estoque.Model.Categoria categoria) {

        Categoria c = repository.findById(id).orElse(null);

        if(c != null){
            c.setNome(categoria.getNome());
            return repository.save(c);
        }

        return null;
    }

    // ele deleta tudo 
    @DeleteMapping("/{id}")
    public void deletar(@PathVariable Long id) {
        repository.deleteById(id);
    }

}
